欢迎进入 金山卫士开源计划 !

在这里你可以接触到中国最专业的安全类软件源代码;
你可以自由的使用／研究／修订／再发布 这些代码以及延伸作品;

进一步的详细信息请访问:
  http://code.ijinshan.com/

= 开源作品根索引 =
./
+-- bksafevul   r101201 漏洞扫描器
+-- ppro        r101201 隐私保护器
+-- sysopt      r101209 系统优化 之 开机加速器

= 代码仓库维护根说明 =
Administrator: Zoom.Quiet <zoomquiet+hg AT gmail.com>
负责:
    + 版本仓库的运维/备份/监察
    + 版本仓库的权限维护
    + 版本仓库的使用响应
    + ...


== 运维随笔 ==
101211 ZoomQuiet:
    + try building official code.google clone sub repo. s
    + hook 多仓库联动同步

101209 ZoomQuiet:
    + rechk hooks for chmod log files...

101202 ZoomQuiet:
    + 测试多仓库hooks 自动同步;error
    遠端: /r/hooks/hook-autoup-hg.s.k.sh: cannot create /opt/_logs/hg/101202-hg-au2up.log: Permission denied
    ...


101201 ZoomQuiet:
    - 清除无用目录/代码
    + 追加两个镜像仓库

101130 ZoomQuiet:
    - reinit. repo.

101115 Zhouqi:
	- testing SSH in M$ ci/pull/merge...
	- fixed hg.s.kingsoft.net log dir's acl error
	
101113 ZoomQuiet:
    - 在 hg.s.kingsoft.net 内网仓库中部署 incoming Hooks
    - 15:53 在 code.ijinshan 主机，也部署 hooks 自动响应所有push
    
101030 #4 (<#3>沟通作者识别代码) – ktrac
    http://code.ijinshan.com/trac/ticket/4
    完成两个现有作品的许可证宣告

101028 通过 SSL 发布可写仓库:
            
101027 21:13 从CentOS 的主机中使用 hg serve 临时发布

