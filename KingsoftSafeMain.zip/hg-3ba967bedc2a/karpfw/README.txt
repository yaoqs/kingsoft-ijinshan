中文名字: 金山卫士ARP防火墙
英文缩写: karpfw
完整英文: kingsoft arp firewall

 
