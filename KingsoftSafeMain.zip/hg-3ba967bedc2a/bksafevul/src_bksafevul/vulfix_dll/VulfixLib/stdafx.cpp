#include "stdafx.h"
#pragma comment(lib, "wininet.lib")