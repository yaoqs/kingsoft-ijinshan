#include <Windows.h>
#include <atlstr.h>
#include "registrywow.h"


