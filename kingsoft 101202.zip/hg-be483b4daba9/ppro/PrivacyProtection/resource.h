//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by PrivacyProtectionGUI.rc
//
#define IDR_SYS                         207
#define IDR_MENU_TRAY                   208
#define ID_TRAYMENU_32775               32775
#define ID_TRAYMENU_32776               32776
#define ID_TRAYMENU_32777               32777
#define ID_ID_MAIN_APP                  32778
#define ID_MAIN_APP                     32779
#define ID_SOS                          32780
#define ID_EXIT                         32781
#define IDC_BTN_SYS_CLOSE               60001
#define IDC_BTN_SYS_MAX                 60002
#define IDC_BTN_SYS_MIN                 60003

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        209
#define _APS_NEXT_COMMAND_VALUE         32782
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
