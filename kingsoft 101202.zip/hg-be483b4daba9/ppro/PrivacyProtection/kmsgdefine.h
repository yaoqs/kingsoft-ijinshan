
#pragma once

//////////////////////////////////////////////////////////////////////////
//all msg
#define MSG_APP_DEFAULT_NAVIGATE            (WM_APP + 1)
#define MSG_CREATE_PAGE						(WM_APP + 2)
#define MSG_UPDATE_PROGRAM_VER				(WM_APP + 3)
#define MSG_UPDATE_VIRUS_DB_VER				(WM_APP + 4)
#define MSG_UPDATE_ENGINE_VER				(WM_APP + 5)
#define MSG_UPDATE_PRODUCT_VER				(WM_APP + 6)
#define MSG_UPDATE_RESULT					(WM_APP + 7)
#define MSG_SELECT_PAGE						(WM_APP + 8)
#define MSG_START							(WM_APP + 9)
#define MSG_TRAYICON						(WM_APP + 10)
#define MSG_UPDATE_CAMERA_INFO				(WM_APP + 11)
#define MSG_UNINSTALL						(WM_APP + 12)
#define MSG_CAMERA_REBOOT					(WM_APP + 13)

