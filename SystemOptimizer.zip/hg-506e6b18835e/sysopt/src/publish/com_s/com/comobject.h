///////////////////////////////////////////////////////////////
//
//	Filename: 	KComObject.h
//	Creator:	lichenglin  <lichenglin@kingsoft.net>
//	Date:		2007-8-25   12:59
//	Comment:	
//
///////////////////////////////////////////////////////////////

#ifndef _KComObject_h_
#define _KComObject_h_


//.-----------------------------------------------------------------------------
// KComObject Decleration, 
//.-----------------------------------------------------------------------------

template <class T>
class KComObject : public T
{
public:
	KComObject();
	~KComObject();

	HRESULT STDMETHODCALLTYPE QueryInterface( REFIID riid, void **ppvObject );
	ULONG   STDMETHODCALLTYPE AddRef();
	ULONG   STDMETHODCALLTYPE Release();

private:
	LONG m_lRefCount;
};





//.-----------------------------------------------------------------------------
// Implemetation
//.-----------------------------------------------------------------------------

template <class T>
KComObject<T>::KComObject()
{
	m_lRefCount = 0;
}



template <class T>
KComObject<T>::~KComObject()
{
}


template <class T>
HRESULT KComObject<T>::QueryInterface( REFIID riid, void **ppvObject )
{
	HRESULT hr = _InternalQueryInterface( riid, ppvObject );

	if( SUCCEEDED( hr ) )
	{
		AddRef();
	}

	return hr;
}


template <class T>
ULONG  KComObject<T>::AddRef()
{
	::InterlockedIncrement( &m_lRefCount );

	return m_lRefCount;
}


template <class T>
ULONG  KComObject<T>::Release()
{
	::InterlockedDecrement( &m_lRefCount );

	if( m_lRefCount == 0 )
	{
		delete this;
		return 0;
	}

	return m_lRefCount;
}




//.-----------------------------------------------------------------------------
// Interface Entry Table
//.-----------------------------------------------------------------------------

/*
[�ӿ�ӳ���:]
KAS_BEGIN_COM_MAP( CComImpl )
	KAS_COM_INTERFACE_ENTRY( IInterface0 )
	KAS_COM_INTERFACE_ENTRY( IInterface1 )
	KAS_COM_INTERFACE_ENTRY( IInterface2 )
KAS_END_COM_MAP()


[��չ��]
HRESULT _InternalQueryInterface( REFIID riid, void **ppvObject )
{
	if( ppv == NULL )
	    return E_INVALIDARG;

	
	HRESULT hr = E_FAIL;

	if( false )
	{
	}

	else if( riid == IID_IInterface0 || riid == IID_IUnknown )
	{
		*ppvObject = static_cast<IInterface0*>(this);
		hr = S_OK;
	}

	else if( riid == IID_IInterface1 || riid == IID_IUnknown )
	{
		*ppvObject = static_cast<IInterface1*>(this);
		hr = S_OK;
	}

	...

	else
	{
		*ppvObject = NULL;
		hr = E_NOINTERFACE;
	}

	return hr;
}

*/


#define SCOM_BEGIN_COM_MAP( CComImpl ) HRESULT _InternalQueryInterface( REFIID riid, void **ppvObject ) { \
    HRESULT hr = E_FAIL; \
    if( ppvObject == NULL ) {return E_INVALIDARG;}

#define SCOM_INTERFACE_ENTRY( I ) 	 else if( riid == __uuidof( I ) || riid == IID_IUnknown ) { \
	*ppvObject = static_cast<I*>(this); \
	hr = S_OK; } 

#define SCOM_INTERFACE_ENTRY2( I1, I2 )     else if( riid == __uuidof( I2 ) || riid == IID_IUnknown ) { \
    *ppvObject = static_cast<I2*>(static_cast<I1*>(this)); \
    hr = S_OK; } 

#define SCOM_INTERFACE_ENTRY_IID( IID__, I )  else if( riid == IID__ || riid == IID_IUnknown ) { \
	*ppvObject = static_cast<I*>(this); \
	hr = S_OK; } 

#define SCOM_END_COM_MAP()  else { \
	*ppvObject = NULL; \
	hr = E_NOINTERFACE; } \
	return hr; }


#endif // _KComObject_h_