
#pragma once

#define XML_PLUG_UPDATE_ROOT					_T("uproot")
#define XML_PLUG_UPDATE_FILE					_T("file")
#define XML_PLUG_UPDATE_FILE_NAME_ATTRIB		_T("name")
#define XML_PLUG_UPDATE_DEL						_T("del")
#define XML_PLUG_UPDATE_DEL_ID_ATTRIB			_T("id")
#define XML_PLUG_UPDATE_ADD						_T("add")
#define XML_PLUG_UPDATE_ITEM					_T("item")
